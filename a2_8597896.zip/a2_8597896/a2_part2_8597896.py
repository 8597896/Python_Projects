'''
ITI 1120
Assignment: 2 part 2
Labelle, Ashley
8597896
'''

########################
# Question 1
########################

def size_format(b):
    '''(number)->string
    Returns a string that represents a number in B, KB, MB, GB, or TB
    '''
    if b<0:
        b=b
        return "buy a new hard disk"
    elif b<1024:
        b=str(round(b,1))
        return b+"B"
    elif b>=1024 and b<1048576:
        b=str(round(b/1024,1))
        return b+"KB"
    elif b>=1048576 and b<1073741824:
        b=str(round(b/1048576,1))
        return b+"MB"
    elif b>=1073741824 and b<1099511627776:
        b=str(round(b/1073741824,1))
        return b+"GB"    
    else:
        b=str(round(b/1099511627776,1))
        return b+"TB"

########################
# Question 2
########################

def add_article(s):
    '''(string)->string
    Returns an article in front of the name of a country that is given
    Preconditions: the language is in french and therefore the articles
    depend on the gender of the country name
    '''
    if s=="Belize" or s=="Cambodge" or s=="Mexique" or s=="Mozambique" or s=="Zaire" or s=="Zimbabwe":
        return "le "+s
    elif s=="Etats-Unis" or s=="Pay-Bas":
        return "les "+s
    elif s[0] in 'AEIOU':
        return "l'"+s
    elif s[-1]=='e':
        return "la "+s
    else:
        return "le "+s

########################
# Question 3
########################

def factorial(n):
    '''(int)->int
    Returns a factorial of input n
    Preconditions: assuming n is a non-negative number
    '''
    if n==0:
        return 1
    else:
        for i in range (1,n):
            n=n*i
        return n

########################
# Question 4
########################

def special_count(l):
    '''(list)->int
    Returns the amount of special numbers in a list
    Preconditions: special numbers must be divisble by 4
    and if >100 they must be divisble by 4,100, and 400
    '''
    count=0
    for item in l:
        if item%100==0 and item>=0:
            if item%4==0 and item%400==0:
                count+=1
        else:
            if item%4==0 and item>=0:
                count+=1
    return count

########################
# Question 5
########################

def vote():
    '''none->string
    Prints a string that describes the outcome of a vote
    '''
    vote=input("Enter the yes, no, abstained votes one by one and then press enter: \n").lower()
    y=0
    n=0
    for check in range(len(vote)):
       if vote[check]=="y":
           y+=1
       if vote[check]=="n" and vote[check+1]!="e":
           n+=1

    if n==0:
        print("proposal passes unanimously")
    elif y/(n+y)>=2/3:
        print("proposal passes with super majority")
    elif y/(n+y)>=1/2:
        print("proposal passes with simple majority")
    else:
        print("proposal fails")

########################
# Question 6
########################

import random

def stats_v1(n):
    '''(int)->none
    Prints a string, a list of randomly generated integers between -100 and 100
    and the minimum and average of that list of integers
    Preconditions: the input must be a positve integer
    '''
    integers=[]
    average=0
    list_of_integers=""
    for i in range (n):
        integers.append(random.randint(-100,100))
        average+=integers[len(integers)-1]
        list_of_integers+=str(integers[len(integers)-1])+" "
    average=average/n
    print("The minimum and the average of the following numbers:")
    print(list_of_integers)
    print("is",min(integers),"and",average)
    
def stats_v2(n):
    '''(int)->none
    Prints a string, a list of randomly generated integers between -100 and 100
    and the minimum and average of that list of integers
    Preconditions: the input must be a positve integer
    '''
    average=0
    print("The minimum and the average of the following numbers:")
    for i in range (n):
        integer=random.randint(-100,100)
        print(integer,end=" ")
        average+=integer
        if average==integer:
            minimum=integer
        else:
            if minimum>integer:
                minimum=integer
    average=average/n
    print("\nis",minimum,"and",average)   

########################
# Question 7
########################

def emphasize(s):
    '''(string)->string
    Returns a string with spaces in between each character
    '''
    string = ""
    if len(s)==1:
        return s
    elif len(s)==0:
        return string
    else:
        for i in s:
            if s[-1]==i:
                string+=i
            else:
                string+=i+" "
        return string

########################
# Question 8
########################

def crypto(s):
    '''(string)->string
    Returns a encrypted string of the input
    '''
    encryption=""
    if len(s)==0:
        return s
    for i in range(len(s)):
        if len(s)==1:
            return s
        encryption+=s[len(s)-1-i]
        if len(s)==len(encryption):
            return encryption
        encryption+=s[i]
        if len(s)==len(encryption):
            return encryption

########################
# Question 9
########################

def stranger_things(l1,l2):
    '''(list,list)->bool
    True is returned if and only if the lists have the same number of elements and every
    pair of elements of l1 and l2 that are at the same even index have to be the same and
    every pair of elemets of l1 and l2 that are at the same odd inex have to be distinct
    '''
    for item in range(len(l1)):
        if item%2==0:
            if len(l1)==len(l2) and l1[item]==l2[item]:
                result=True
            else:
                return False
        else:
            if len(l1)==len(l2) and l1[item]!=l2[item]:
                result=True
            else:
                return False
    return result
