'''
ITI 1120
Assignment: 2 part 1
Labelle, Ashley
8597896
'''

import random

def perform_test():
    '''(none)->none
    Performs a test and prints a message based on the performance of the user
    Precondtions: n is greater than or equal to zero
    '''
    score=0
    choice=int(input("Welcome to Math Help! Which practice test would you like to do? \n(0 for addition and 1 for multiplication) \n"))
    while choice>1 or choice<0:
        choice=int(input(("Please type 0 or 1 \n")))
    n=int(input("How many questions would you like your test to have?"))
    if n==0:
        print("Good bye!")
    else:
            
        if choice==0:
            for q in range (n):
                n1=random.randint(0,9)
                n2=random.randint(0,9)
                total=(n1+n2)
                print(n1,"+",n2)
                a=int(input("="))

                if a==total:
                    print("Correct!")
                    score += 1
                else:
                    print("Incorrect. The answer is ", n1+n2)

        else:
            for q in range (n):
                n1=random.randint(0,9)
                n2=random.randint(0,9)
                total=(n1*n2)
                print(n1,"*",n2)
                a=int(input("="))

                if a==total:
                    print("Correct!")
                    score += 1
                else:
                    print("Incorrect. The answer is ", n1*n2)

        percent=score/n*100

        if percent>=80:
            print("Well done! Congradulations.")         
        elif percent>=60:
            print("Not too bad but please study and practice some more.")
        else:
            print("Please study more and ask your teacher for help.")



    
