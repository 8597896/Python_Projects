'''
ITI 1120
Assignment: 1
Labelle, Ashley
8597896
'''
  
########################
# Question 1
########################

def lbs2kg(w):
    '''(number)->number
    Returns a given weight in lbs to kg
    Precondition: given weight is a non-negative number
    '''
    return w/2.20462

#######################
# Question 2
#######################

def id_formater(fn, ln, appellation, city, year):
    '''(string)->string
    Prints a format for identification information
    '''
    print (appellation, ".", ln, ",", fn, "(", city, ",", year, ")")

#######################
# Question 3
#######################

def limerick_maker():
    '''(string)->string
    Recieves a name and a city of birth to complete a limerick
    Precondition: givens are strings
    '''
    name = input("Enter your name: ")
    city = input("Enter your city of birth: ")
    print (name, " had funny funny hair \n With tons and tons to spare \n", name, "'s clippings made a wig \n It was very big \n And caused the townsfolk of Mostar to stare")

#######################
# Question 4
#######################

def id_formater_display():
    '''(input)->string
    Recieves information, that satisfies the function id_formater, from the user
    and prints a format for the identification informmation
    '''
    fn = input("What is your first name?")
    ln = input("What is your last name?")
    appellation = input("What s your appellation?")
    city = input("Where were you born?")
    year = input("What is the your year of birth?")
    id_formater(fn, ln, appellation, city, year)

#######################
# Question 5
#######################

def l2loz(w):
    '''(number)->number,number
    Returns a pair of nujmbers (l,o) such that w = l+o/16 and l is an integer
    and o is a non-negative numner less than 16
    Precondition: the given number is non-negative
    '''
    l = int(w)
    o = (w-int(w))*16
    return l,o

#######################
# Question 6
#######################
import turtle
t=turtle.Turtle(shape='turtle')

def draw_soccer_field():
    '''(None)->None
    Draws a soccor field using turtle graphics
    '''
    # draw a rectangle
    t.penup()
    t.goto(-250,-150)
    t.pendown()
    t.goto(-250,150)
    t.forward(500)
    t.right(90)
    t.forward(300)
    t.right(90)
    t.forward(500)
    # draw left rectangle
    t.penup()
    t.goto(-250,-100)
    t.pendown()
    t.right(180)
    t.forward(100)
    t.left(90)
    t.forward(200)
    t.left(90)
    t.forward(100)
    # draw left inner rectangle
    t.penup()
    t.goto(-250,-50)
    t.pendown()
    t.right(180)
    t.forward(40)
    t.left(90)
    t.forward(100)
    t.left(90)
    t.forward(40)
    # draw right rectangle
    t.penup()
    t.goto(250,-100)
    t.pendown()
    t.right(0)
    t.forward(100)
    t.right(90)
    t.forward(200)
    t.right(90)
    t.forward(100)
    # draw right inner rectangle
    t.penup()
    t.goto(250,-50)
    t.pendown()
    t.right(180)
    t.forward(40)
    t.right(90)
    t.forward(100)
    t.right(90)
    t.forward(40)
    # centre line
    t.penup()
    t.goto(0,-150)
    t.pendown()
    t.left(90)
    t.forward(300)
    # centre outer circle
    t.penup()
    t.goto(0,-50)
    t.pendown()
    t.right(90)
    t.circle(50,360)
    # centre inner circle
    t.penup()
    t.goto(0,-5)
    t.pendown()
    t.left(0)
    t.circle(5,360)
    # left semi circle
    t.penup()
    t.goto(-150,-40)
    t.pendown()
    t.right(0)
    t.circle(40, 180)
    # right semi circle
    t.penup()
    t.goto(150,40)
    t.pendown()
    t.right(0)
    t.circle(40,180)
    # top left corner
    t.penup()
    t.goto(-250,140)
    t.pendown()
    t.circle(10,90)
    # bottom left corner
    t.penup()
    t.goto(-240,-150)
    t.pendown()
    t.circle(10,90)
    # bottom right corner
    t.penup()
    t.goto(250,-140)
    t.pendown()
    t.circle(10,90)
    # top left corner
    t.penup()
    t.goto(240,150)
    t.pendown()
    t.circle(10,90)
    # left circle
    t.penup()
    t.goto(-180,-2.5)
    t.pendown()
    t.circle(5,360)
    # right circle
    t.penup()
    t.goto(180,-2.5)
    t.pendown()
    t.circle(5,360)

draw_soccer_field()

#######################
# Question 7
#######################

def median3(num1,num2,num3):
    '''(number, number, number)->string)
    Prints a message about the median of a given set of 3 numbers
    '''
    high=max(num1,num2,num3)
    low=min(num1,num2,num3)
    median=(num1 + num2 + num3)-(high + low)
    print (num1, "is a median. That is", num1==median)
    print (num2, "is a median. That is", num2==median)
    print (num3, "is a median. That is", num3==median)

#######################
# Question 8
#######################
import math

def below_parabola(a,b,p,q):
    ''' (set of numbers)->boolean
    Returns p<=a*q**2+b and q<=(p-b)/a*math.sqrt(q)
    which is based off of the given quadratic function and a rearranged version
    to solve for cooridnates (p,q) '''
    return p<=a*q**2+b and q<=(p-b)/a*math.sqrt(q)

#######################
# Question 9
#######################
def projected_grade(a1,A1,a2,A2,m,M):
    '''(set of numbers)->number
    Returns a projected grade
    '''
    grade=(a1/A1*7.5)+(a2/A2*7.5)+(m/M*85)
    return grade

#######################
# Question 10
#######################
def projected_grade_v2():
    '''(set of numbers)->number
    Recieves input from user to return a projected grade as well as include a
    punishment for students who fail the midterm; meaning that students who fail the midterm,
    will fail overall
    '''
    a1 = float(input("How many points did you get in Assignment 1? "))
    A1 = float(input("What was the maximum possible number of points for Assignment 1? "))
    a2 = float(input("How many points did you get in Assignment 2? "))
    A2 = float(input("What was the maximum possible number of points for Assignment 2? "))
    m = float(input("How many points did you get on the midterm? "))
    M = float(input("What was the maximum possible number of points for the midterm? "))
    grade=projected_grade(a1,A1,a2,A2,m,M)
    if m/M*100<50 and m/M*100<grade:
        percent=m/M*100
    else: percent=grade
    print ("Your predicted final grade is", percent, "%")

#######################
# Question 11
#######################
def change_to_coins(amount):
    '''(number)->number,number,number,number
    Returns the amount of quarters, dimes, nickels, and pennies while aiming
    for an outcome that outputs the least amount of coins
    '''
    amount = round(amount*100)
    q = amount//25
    amount = amount%25
    d = amount//10
    amount = amount%10
    n = amount//5
    amount = amount%5
    p = amount//1
    return q,d,n,p
