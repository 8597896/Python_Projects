'''
ITI 1120
Assignment: 3 GAME
Labelle, Ashley
8597896
'''

# In this implementation a card (that is not a 10) is represented
# by a 2 character string, where the 1st character represents a rank and the 2nd a suit.
# Each card of rank 10 is represented as a 3 character string, first two are the rank and the 3rd is a suit.

import random

def wait_for_player():
    '''()->None
    Pauses the program until the user presses enter
    '''
    try:
         input("\nPress enter to continue. ")
         print()
    except SyntaxError:
         pass


def make_deck():
    '''()->list of str
        Returns a list of strings representing the playing deck,
        with one queen missing.
    '''
    deck=[]
    suits = ['\u2660', '\u2661', '\u2662', '\u2663']
    ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    for suit in suits:
        for rank in ranks:
            deck.append(rank+suit)
    deck.remove('Q\u2663') # remove a queen as the game requires
    return deck

def shuffle_deck(deck):
    '''(list of str)->None
       Shuffles the given list of strings representing the playing deck    
    '''
    random.shuffle(deck)

#####################################

def deal_cards(deck):
     '''(list of str)-> tuple of (list of str,list of str)

     Returns two lists representing two decks that are obtained
     after the dealer deals the cards from the given deck.
     The first list represents dealer's i.e. computer's deck
     and the second represents the other player's i.e user's list.
     '''
     dealer=[]
     other=[]

     # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE

     for card in range (len(deck)):
         if card%2==0:
             dealer.append(deck[card])
         else:
             other.append(deck[card])

     # YOUR CODE GOES HERE

     return (dealer, other)
 


def remove_pairs(l):
    '''
     (list of str)->list of str

     Returns a copy of list l where all the pairs from l are removed AND
     the elements of the new list shuffled

     Precondition: elements of l are cards represented as strings described above

     Testing:
     Note that for the individual calls below, the function should
     return the displayed list but not necessarily in the order given in the examples.

     >>> remove_pairs(['9♠', '5♠', 'K♢', 'A♣', 'K♣', 'K♡', '2♠', 'Q♠', 'K♠', 'Q♢', 'J♠', 'A♡', '4♣', '5♣', '7♡', 'A♠', '10♣', 'Q♡', '8♡', '9♢', '10♢', 'J♡', '10♡', 'J♣', '3♡'])
     ['10♣', '2♠', '3♡', '4♣', '7♡', '8♡', 'A♣', 'J♣', 'Q♢']
     >>> remove_pairs(['10♣', '2♣', '5♢', '6♣', '9♣', 'A♢', '10♢'])
     ['2♣', '5♢', '6♣', '9♣', 'A♢']
    '''

    no_pairs=[]

    # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE
    l.sort()
    count_pairs=1
    prev_card=""
    for a in range(len(l)-1):
        if prev_card!=l[a][0]:
            count_pairs=1
        if l[a][0] not in l[a+1] and count_pairs%2!=0:
            no_pairs.append(l[a])
            count_pairs=1
        else:
            count_pairs+=1
        prev_card=l[a][0]
    if count_pairs%2!=0:
        if prev_card!=l[len(l)-1][0]:
            no_pairs.append(l[len(l)-1])
         
    # YOUR CODE GOES HERE

    random.shuffle(no_pairs)
    return no_pairs

def print_deck(deck):
    '''
    (list)->None
    Prints elements of a given list deck separated by a space
    '''
    
    # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE

    deck_string=""
    for item in deck:
        deck_string+=str(item)+" "
    print (deck_string)

    # YOUR CODE GOES HERE

    
def get_valid_input(n):
     '''
     (int)->int
     Returns an integer given by the user that is at least 1 and at most n.
     Keeps on asking for valid input as long as the user gives integer outside of the range [1,n]
     
     Precondition: n>=1
     '''

     # COMPLETE THE BODY OF THIS FUNCTION ACCORDING TO THE DESCRIPTION ABOVE

     i=int(input("Give me an integer between 1 and "+str(n)+": "))
     while i<1 or i>n:
         i=int(input("Invalid number. Please enter integer between 1 and "+str(n)+": "))
     return i    

     # YOUR CODE GOES HERE

def play_game():
     '''()->None
     This function plays the game'''
    
     deck=make_deck()
     shuffle_deck(deck)
     tmp=deal_cards(deck)

     dealer=tmp[0]
     human=tmp[1]

     print("Hello. My name is Robot and I am the dealer.")
     print("Welcome to my card game!")
     print("Your current deck of cards is:")
     print_deck(human)
     print("Do not worry. I cannot see the order of your cards")

     print("Now discard all the pairs from your deck. I will do the same.")
     wait_for_player()
     
     dealer=remove_pairs(dealer)
     human=remove_pairs(human)
     
     # COMPLETE THE play_game function HERE

     while len(dealer)!=0 and len(human)!=0:   
         print ("***********************************************************")
         print ("Your turn.\n")
         print ("Your current deck of cards is:\n")

         print_deck(human)

         print ("\nI have "+str(len(dealer))+" cards. If 1 stands for my first card and")
         print (str(len(dealer))+" for my last card, which of my cards would you like?")

         choice=get_valid_input(len(dealer))
         hChoice=str(choice)

         if choice==1:
             print ("You asked for my "+hChoice+"st card")
         elif choice==2:
             print ("You asked for my "+hChoice+"nd card")
         elif choice==3:
             print ("You asked for my "+hChoice+"rd card")
         else:
             print ("You asked for my "+hChoice+"th card")

         print ("Here it is. It is "+dealer[choice-1]+"\n")
         print ("With "+dealer[choice-1]+" added, your current deck of cards is:\n")

         human.append(dealer[choice-1])
         dealer.remove(dealer[choice-1])
         print_deck(human)

         print ("\nAnd after discarding pairs and shuffling, your deck is:\n")

         human=remove_pairs(human)
         print_deck(human)

         print ("")
            
         wait_for_player()

         if len(human)==0:
             print("Ups. You do not have any more cards")
             print("Congratulations! You, Human, win")
             break
         elif len(dealer)==0:
             print("Ups. I do not have any more cards")
             print("You lost! I, Robot, win")
             break

         print ("***********************************************************")
         print ("My turn.\n")

         dealer_choice=random.randint(1,len(human))
         dChoice = str(dealer_choice)

         if dealer_choice==1:
             print ("I took your "+dChoice+"st card.")
         elif dealer_choice==2:
             print ("I took your "+dChoice+"nd card.")
         elif dealer_choice==3:
             print ("I took your "+dChoice+"rd card.")
         else:
             print ("I took your "+dChoice+"th card.")

         dealer.append(human[dealer_choice-1])
         human.remove(human[dealer_choice-1])

         human=remove_pairs(human)
         dealer=remove_pairs(dealer)

         wait_for_player()

         if len(human)==0:
             print("Ups. You do not have any more cards")
             print("Congratulations! You, Human, win")
             break
         elif len(dealer)==0:
             print("Ups. I do not have any more cards")
             print("You lost! I, Robot, win")
             break

     # YOUR CODE GOES HERE
	
	 

# main
play_game()
