'''
ITI 1120
Assignment: 3 Question 2
Labelle, Ashley
8597896
'''

def two_length_run(l):
    '''(list)->(bool)
    Returns a boolean that tells the user if a given list contains a run
    '''
    for i in range(len(l)):
        for j in range(i+1,len(l)):
            if l[i]==l[i+1]:
                return True        
    return False

# Main
s = input("Please input a list of numbers separated by commas: \n")
if len(s)>1:
    l = list(eval(s))
    print (two_length_run(l))
else:
    print (two_length_run(l))
