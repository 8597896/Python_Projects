'''
ITI 1120
Assignment: 3 Question 1
Labelle, Ashley
8597896
'''

def count_pos(l):
    '''(list)->(string)
    Prints a string that describes the number of positive numbers in a given list
    '''
    pos_nums=0
    for i in l:
        if i>0:
            pos_nums+=1
    print ("There are", pos_nums, "positive numbers in your list.")

# Main
s = input("Please input a list of numbers separated by commas: \n")
if len(s)>1:
    l = list(eval(s))
    count_pos(l)
if len(s)==1:
    l = int(s)
    if l>0:
        pos_nums=1
    else:
        pos_nums=0
    print ("There are", pos_nums, "positive numbers in your list.")
if len(s)==0:
    pos_nums=0
    print ("There are", pos_nums, "positive numbers in your list.")


