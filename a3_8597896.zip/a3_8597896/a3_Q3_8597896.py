'''
ITI 1120
Assignment: 3 Question 3
Labelle, Ashley
8597896
'''

def longest_run(l):
    '''(list)->(int)
    Prints an integer that represents the amount of runs in a given list.
    '''
    length=0
    longest=0
    for i in range(len(l)):
        for j in range(i+1,len(l)-1):
            if l[i]==l[j]:
                length+=1
                if longest<length:
                    longest=length
            else:
                length=0
    return longest+1

# Main
s = input("Please input a list of numbers separated by commas: \n")
if len(s)>1:
    l = list(eval(s))
    print (longest_run(l))
elif len(s)==1:
    print (1)
